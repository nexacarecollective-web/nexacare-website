# Nexacare Collective - NDIS Website

This is a basic static website for Nexacare Collective, an NDIS care and support service provider in Australia.

## Pages
- Home / About
- Services
- Contact (form is placeholder only)

## Instructions
Deploy this website using Vercel or any static hosting service. You can also connect a custom domain like `nexacarecollective.com`.

---

Created by Abdi Mohamed, 2025.